```
.mmm,          .m,          .,  W                 .mm,  .m, .mm, 
]P""`          'T[          ][  "                 ]P"T[ W"W ]P"T[
][   'W W`]bWb  ][   dWb  dWd[ WW  ]bWW, dWd[     ][ ][][ ][][ ][
]WWW  ]W[ ]P T[ ][  ]P T[]P T[  W  ]P ][]P T[     ]WWW ][ ][]WWW 
][    .W, ][ ][ ][  ][ ][][ ][  W  ][ ][][ ][     ][ ][][ ][][ ][
]bmm, d"b ]WmW` ]bm 'WmW`'WmW[.mWm,][ ]['WmW[     ]bmd[ WmW ]bmd[
'"""`'" "`]["`   ""  '"`  '"'`'"""`'` '` /"][     '"""  '"` '""" 
          ][                             TWP`                    
```

An educational game created for the [Apps4Learning](https://web.archive.org/web/20160129080846/http://www.apps4learning.ca/) program.

https://gelatolabs.xyz/explodingbob/

Credits
=======
* Kyle Farwell (kfarwell): Programming
* Peter Brunner (petvader99): Graphics
* Matthew Rose: Graphics
* Katie Horne: Graphics
