```
 ▗▖                          ▖▖                                                 
 ▝▘              ▗      ▗▄▄  ▄▄ ▗  ▖ ▗          ▗▄▄  ▗▖ ▗  ▖    ▗▄▄             
 ▗▖ ▗▗▖  ▄▄  ▄▖ ▗▟▄     ▐ ▝▌▗▘▝▖▐▌▐▌ ▐   ▄▖     ▐ ▝▌ ▐▌ ▐▌▐▌    ▐ ▝▌ ▄▖  ▄▄  ▄▖ 
 ▐▌ ▐▘▐ ▐▘▜ ▐ ▝  ▐      ▐▄▄▘▐  ▌▐▐▌▌    ▐ ▝     ▐▄▄▘ ▌▐ ▐▐▌▌    ▐▄▟▘▝ ▐ ▐▘▜ ▐▘▐ 
 ▙▟ ▐ ▐ ▐ ▐  ▀▚  ▐   ▀▘ ▐ ▝▖▐  ▌▐▝▘▌     ▀▚     ▐ ▝▖ ▙▟ ▐▝▘▌    ▐   ▗▀▜ ▐ ▐ ▐▀▀ 
▗▘▝▖▐ ▐ ▝▙▜ ▝▄▞  ▝▄     ▐  ▘ ▙▟ ▐  ▌    ▝▄▞     ▐  ▘▐  ▌▐  ▌    ▐   ▝▄▜ ▝▙▜ ▝▙▞ 
         ▖▐                                                              ▖▐     
         ▝▘                                                              ▝▘     
```

A puzzle game made for the Ludum Dare 36 72-hour game development jam.

Join Ångst-RÖM on his quest to liberate his computer from NSA spyware and replace Macindows with the GNOO / Gelato System.

https://gelatolabs.xyz/angstromsrampage/

Credits
=======
* Kyle Farwell (kfarwell): Programming
* Keefer Rourke (krourke): Programming
* Matthew Petry (fire219): Graphics and audio
* Phil St. Antoine (squid): Puzzle design
