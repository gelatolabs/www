```
 ⢹⠁ ⣇⡀ ⢀⡀   ⡇ ⣀⡀ ⢀⡀ ⡇ ⢀⡀ ⡀⣀ ⠄ ⢀⡀ ⡀⢀ ⢀⣀   ⢇⢸ ⢀⡀ ⣰⡀   ⣇⣸ ⠄ ⢀⡀ ⣇⡀ ⡇ ⡀⢀
 ⠸  ⠇⠸ ⠣⠭   ⠇ ⠇⠸ ⣑⡺ ⠣ ⠣⠜ ⠏  ⠇ ⠣⠜ ⠣⠼ ⠭⠕    ⠇ ⠣⠭ ⠘⠤   ⠇⠸ ⠇ ⣑⡺ ⠇⠸ ⠣ ⣑⡺
 ⢎⡑ ⣰⡀ ⠄ ⣀⣀  ⡀⢀ ⡇ ⢀⣀ ⣰⡀ ⠄ ⣀⡀ ⢀⡀   ⡇  ⠄ ⣰⡁ ⢀⡀   ⢀⡀ ⣰⡁   ⢀⣀ ⣀⡀
 ⠢⠜ ⠘⠤ ⠇ ⠇⠇⠇ ⠣⠼ ⠣ ⠣⠼ ⠘⠤ ⠇ ⠇⠸ ⣑⡺   ⠧⠤ ⠇ ⢸  ⠣⠭   ⠣⠜ ⢸    ⠣⠼ ⠇⠸
 ⡇⢸ ⣀⡀ ⢀⣸ ⢀⡀ ⡀⣀ ⣀⡀ ⢀⣀ ⠄ ⢀⣸   ⡎⠑ ⡀⣀ ⢀⣀ ⢀⣸ ⡀⢀ ⢀⣀ ⣰⡀ ⢀⡀   ⢎⡑ ⣰⡀ ⡀⢀ ⢀⣸ ⢀⡀ ⣀⡀ ⣰⡀
 ⠣⠜ ⠇⠸ ⠣⠼ ⠣⠭ ⠏  ⡧⠜ ⠣⠼ ⠇ ⠣⠼   ⠣⠝ ⠏  ⠣⠼ ⠣⠼ ⠣⠼ ⠣⠼ ⠘⠤ ⠣⠭   ⠢⠜ ⠘⠤ ⠣⠼ ⠣⠼ ⠣⠭ ⠇⠸ ⠘⠤
```

A tech support simulator made for the Ludum Dare 33 72-hour game development jam.

Inspired by our net connections cutting out right after the theme was announced and some fun times with ISPs' phone support, we made a game where you provide terrible tech support to innocent civilians for sweet cash to buy more phones on ePay. You monster.

https://gelatolabs.xyz/tiyhsloaugs/

Credits
=======
* Kyle Farwell (kfarwell): Programming
* Keefer Rourke (krourke): Programming
* Matthew Petry (fire219): Graphics and audio
* Peter Brunner (petvader99): Graphics
