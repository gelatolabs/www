```
 ##  #                  ##               #           #   #          
#    #  ### ### ###     # # ### ### ###     # #  ## ###     ### ##  
 #   #  ##  ##  # #     # # ##  # # #    #  # # # #  #   #  # # # # 
  #  ## ### ### ###     # # ### ### #    ##  #  ###  ##  ## ### # # 
##              #       ##      #                                   
                                                                
          #     ##        #     # #      #   #   #              
 ## ##  ###     # #  ## ###     # # ###     ###     ##  ###  #  
# # # # # #     ##  # # # #     ### #    #   #   #  # # # #     
### # # ###     # # ### ###     ### #    ##  ##  ## # #  ##  #  
                ##              # #                     ###     
                                                                
### #           # #  #               #      ###              #  
 #  ### ###     # #      ## # #  ##  #      # # ### # # ###  #  
 #  # # ##      # #  #   #  # # # #  #      # # # # # # ##   #  
 #  # # ###     # #  ## ##  ### ###  ##     # # ###  #  ###  ## 
 #               #                          # #                 
```

A visual novel made for the Ludum Dare 38 72-hour game development jam.

"oh my god
im going through this game
im losing brain cells" -mustafa

https://gelatolabs.xyz/sdbwvn/

Credits
=======
* Kyle Farwell (kfarwell): Writing, programming, and graphics
* Mustafa Abdul Razaq (mustafa): Graphics
* Matthew Petry (fire219): Audio
